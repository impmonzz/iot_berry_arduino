#ifndef SECRETS_H
#define SECRETS_H

#define WIFI_SSID "KT_GiGA_0BF0"
#define WIFI_PASSWORD "bke72cg443"
const char* apiKey = "AIzaSyAvuVZ1-Ugem5kHBhg2TEEGaX1PxxJBHaI";
const char* FIREBASE_PROJECT_ID = "dju-berry-iot-8140";

#endif // SECRETS_H