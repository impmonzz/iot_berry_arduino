
#ifndef SECRETS_H
#define SECRETS_H

// Wi-Fi 설정
#define WIFI_SSID "KT_GiGA_0BF0"
#define WIFI_PASSWORD "bke72cg443"

// Firebase 설정
#define FIREBASE_PROJECT_ID "dju-berry-iot-8140"
#define FIREBASE_API_KEY "AIzaSyAvuVZ1-Ugem5kHBhg2TEEGaX1PxxJBHaI"

// MQTT 설정
#define MQTT_SERVER "test.mosquitto.org"
#define MQTT_PORT 1883

// API 키 변수 정의
const char* apiKey = FIREBASE_API_KEY;

#endif // SECRETS_H
